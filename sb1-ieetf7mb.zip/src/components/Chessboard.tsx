import React, { useEffect, useState } from 'react';
import { useGameStore } from '../stores/gameStore';

interface Square {
  piece: string | null;
  isSelected: boolean;
  isValidMove: boolean;
}

const PIECE_IMAGES = {
  'wp': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wP.svg',
  'wr': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wR.svg',
  'wn': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wN.svg',
  'wb': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wB.svg',
  'wq': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wQ.svg',
  'wk': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/wK.svg',
  'bp': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bP.svg',
  'br': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bR.svg',
  'bn': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bN.svg',
  'bb': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bB.svg',
  'bq': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bQ.svg',
  'bk': 'https://raw.githubusercontent.com/lichess-org/lila/master/public/piece/cburnett/bK.svg'
};

export default function Chessboard() {
  const { chess, makeMove } = useGameStore();
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [board, setBoard] = useState<Square[][]>(getInitialBoard());

  useEffect(() => {
    updateBoard();
  }, [chess]);

  function getInitialBoard() {
    const board: Square[][] = [];
    for (let i = 0; i < 8; i++) {
      board[i] = [];
      for (let j = 0; j < 8; j++) {
        board[i][j] = {
          piece: null,
          isSelected: false,
          isValidMove: false
        };
      }
    }
    return board;
  }

  function updateBoard() {
    const newBoard = getInitialBoard();
    const position = chess.board();

    position.forEach((row, i) => {
      row.forEach((piece, j) => {
        if (piece) {
          newBoard[i][j].piece = `${piece.color}${piece.type}`;
        }
      });
    });

    if (selectedSquare) {
      const [file, rank] = selectedSquare.split('');
      const i = 8 - parseInt(rank);
      const j = file.charCodeAt(0) - 97;
      newBoard[i][j].isSelected = true;

      // Show valid moves
      const moves = chess.moves({ square: selectedSquare, verbose: true });
      moves.forEach(move => {
        const targetI = 8 - parseInt(move.to[1]);
        const targetJ = move.to.charCodeAt(0) - 97;
        newBoard[targetI][targetJ].isValidMove = true;
      });
    }

    setBoard(newBoard);
  }

  function handleSquareClick(i: number, j: number) {
    const file = String.fromCharCode(97 + j);
    const rank = 8 - i;
    const square = `${file}${rank}`;

    if (selectedSquare === null) {
      const piece = chess.get(square);
      if (piece && piece.color === (chess.turn() === 'w' ? 'w' : 'b')) {
        setSelectedSquare(square);
      }
    } else {
      if (square !== selectedSquare) {
        makeMove(selectedSquare, square);
      }
      setSelectedSquare(null);
    }

    updateBoard();
  }

  return (
    <div className="w-full max-w-2xl aspect-square">
      <div className="grid grid-cols-8 h-full">
        {board.map((row, i) =>
          row.map((square, j) => {
            const isLight = (i + j) % 2 === 0;
            const pieceKey = square.piece ? (square.piece[0] + square.piece[1].toLowerCase()) : null;
            
            return (
              <button
                key={`${i}-${j}`}
                className={`
                  relative
                  ${isLight ? 'bg-amber-100' : 'bg-amber-800'}
                  ${square.isSelected ? 'ring-2 ring-blue-500' : ''}
                  ${square.isValidMove ? 'after:absolute after:inset-0 after:bg-green-500 after:bg-opacity-30 after:rounded-full after:m-3' : ''}
                  hover:opacity-90
                  transition-opacity
                `}
                onClick={() => handleSquareClick(i, j)}
              >
                {pieceKey && PIECE_IMAGES[pieceKey as keyof typeof PIECE_IMAGES] && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <img
                      src={PIECE_IMAGES[pieceKey as keyof typeof PIECE_IMAGES]}
                      alt={pieceKey}
                      className="w-3/4 h-3/4"
                      draggable={false}
                    />
                  </div>
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}