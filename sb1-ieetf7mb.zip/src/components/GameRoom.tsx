import React, { useEffect } from 'react';
import { useGameStore } from '../stores/gameStore';
import Chessboard from './Chessboard';
import { Clock, MessageCircle } from 'lucide-react';

interface GameRoomProps {
  gameId: string;
}

export default function GameRoom({ gameId }: GameRoomProps) {
  const { game, moves, joinGame, error } = useGameStore();

  useEffect(() => {
    joinGame(gameId);
  }, [gameId]);

  if (error) {
    return <div className="text-red-500">{error}</div>;
  }

  if (!game) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left sidebar - Player info */}
        <div className="space-y-4">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">Black Player</h3>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Player Name</span>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-gray-400 mr-2" />
                <span className="text-gray-300">10:00</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center - Chessboard */}
        <div className="lg:col-span-1">
          <Chessboard />
          <div className="mt-4 flex justify-between items-center">
            <button className="px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400">
              Offer Draw
            </button>
            <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-400">
              Resign
            </button>
          </div>
        </div>

        {/* Right sidebar - Chat and moves */}
        <div className="space-y-4">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">White Player</h3>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Player Name</span>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-gray-400 mr-2" />
                <span className="text-gray-300">10:00</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <MessageCircle className="w-5 h-5 text-gray-400 mr-2" />
              <h3 className="text-lg font-semibold text-white">Chat</h3>
            </div>
            <div className="h-48 overflow-y-auto mb-4 space-y-2">
              {/* Chat messages will go here */}
            </div>
            <div className="flex items-center">
              <input
                type="text"
                placeholder="Type a message..."
                className="flex-1 bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <button className="ml-2 px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400">
                Send
              </button>
            </div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">Moves</h3>
            <div className="h-48 overflow-y-auto">
              {moves.map((move, index) => (
                <div key={move.id} className="text-gray-300">
                  {index + 1}. {move.move}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}