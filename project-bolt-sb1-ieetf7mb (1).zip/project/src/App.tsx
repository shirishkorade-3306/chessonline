import React, { useEffect } from 'react';
import { useGameStore } from './stores/gameStore';
import { useAuthStore } from './stores/authStore';
import { supabase } from './lib/supabase';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import GameRoom from './components/GameRoom';
import GameLobby from './components/GameLobby';
import Auth from './components/Auth';

function App() {
  const { user } = useAuthStore();
  const { game } = useGameStore();
  const gameId = new URLSearchParams(window.location.search).get('gameId');

  // Handle auth redirect
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      useAuthStore.setState({ user: session?.user ?? null });
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      useAuthStore.setState({ user: session?.user ?? null });
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (gameId && user) {
      // Join game if URL contains gameId
      useGameStore.getState().joinGame(gameId);
    }
  }, [gameId, user]);

  // Show game room if in a game
  if (game) {
    return <GameRoom gameId={game.id} />;
  }

  // Show game lobby if logged in but not in a game
  if (user && !game) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Navbar />
        <GameLobby />
      </div>
    );
  }

  // Show login/signup if not authenticated
  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900">
        <Navbar />
        <Auth />
      </div>
    );
  }

  // Show landing page
  return (
    <div className="min-h-screen bg-gray-900">
      <Navbar />
      <main>
        <Hero />
        <Features />
      </main>
    </div>
  );
}

export default App;