import { create } from 'zustand';
import { Chess } from 'chess.js';
import { supabase } from '../lib/supabase';
import type { Database } from '../lib/database.types';

type Game = Database['public']['Tables']['games']['Row'];
type Move = Database['public']['Tables']['moves']['Row'];

interface GameState {
  game: Game | null;
  chess: Chess;
  moves: Move[];
  loading: boolean;
  error: string | null;
  createGame: () => Promise<string>;
  joinGame: (gameId: string) => Promise<void>;
  makeMove: (from: string, to: string) => Promise<void>;
  subscribeToGame: (gameId: string) => void;
  unsubscribeFromGame: () => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  game: null,
  chess: new Chess(),
  moves: [],
  loading: false,
  error: null,

  createGame: async () => {
    try {
      set({ loading: true, error: null });
      const user = await supabase.auth.getUser();
      
      const { data: game, error } = await supabase
        .from('games')
        .insert({
          white_player: user.data.user?.id,
          status: 'waiting',
          current_position: new Chess().fen() // Initialize with starting position
        })
        .select()
        .single();

      if (error) throw error;
      set({ game, loading: false });
      return game.id;
    } catch (error) {
      set({ error: (error as Error).message, loading: false });
      throw error;
    }
  },

  joinGame: async (gameId: string) => {
    try {
      set({ loading: true, error: null });
      const user = await supabase.auth.getUser();

      // Check if game exists and get current state
      const { data: game, error: fetchError } = await supabase
        .from('games')
        .select('*, moves(*)')
        .eq('id', gameId)
        .single();

      if (fetchError) throw fetchError;

      // Load the current game state
      const chess = new Chess();
      if (game.current_position) {
        chess.load(game.current_position);
      }

      // Set up the moves history
      const moves = game.moves || [];
      set({ game, chess, moves, loading: false });
      get().subscribeToGame(gameId);

      // Join as black player if the game is waiting and you're not the white player
      if (game.status === 'waiting' && game.white_player !== user.data.user?.id) {
        const { error: updateError } = await supabase
          .from('games')
          .update({
            black_player: user.data.user?.id,
            status: 'active'
          })
          .eq('id', gameId);

        if (updateError) throw updateError;
      }
    } catch (error) {
      set({ error: (error as Error).message, loading: false });
    }
  },

  makeMove: async (from: string, to: string) => {
    try {
      const { chess, game } = get();
      if (!game) throw new Error('No active game');

      const user = await supabase.auth.getUser();
      const isWhite = game.white_player === user.data.user?.id;
      const isBlack = game.black_player === user.data.user?.id;
      
      if (!isWhite && !isBlack) throw new Error('Not a player in this game');
      if ((chess.turn() === 'w' && !isWhite) || (chess.turn() === 'b' && !isBlack)) {
        throw new Error('Not your turn');
      }

      const move = chess.move({ from, to });
      if (!move) throw new Error('Invalid move');

      const { error } = await supabase
        .from('moves')
        .insert({
          game_id: game.id,
          player_id: user.data.user?.id,
          move: move.san,
          position: chess.fen()
        });

      if (error) throw error;

      // Update game state
      const gameStatus = chess.isGameOver() ? 'completed' : 'active';
      const winner = chess.isCheckmate() ? user.data.user?.id : null;

      await supabase
        .from('games')
        .update({
          current_position: chess.fen(),
          status: gameStatus,
          winner: winner
        })
        .eq('id', game.id);

      set({ chess: new Chess(chess.fen()) });
    } catch (error) {
      set({ error: (error as Error).message });
    }
  },

  subscribeToGame: (gameId: string) => {
    // Subscribe to moves
    const movesSubscription = supabase
      .channel(`game:${gameId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'moves',
          filter: `game_id=eq.${gameId}`
        },
        (payload) => {
          const move = payload.new as Move;
          const chess = new Chess();
          chess.load(move.position);
          set((state) => ({ 
            chess,
            moves: [...state.moves, move]
          }));
        }
      )
      .subscribe();

    // Subscribe to game status changes
    const gameSubscription = supabase
      .channel(`game:${gameId}:status`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'games',
          filter: `id=eq.${gameId}`
        },
        (payload) => {
          set({ game: payload.new as Game });
        }
      )
      .subscribe();

    return () => {
      movesSubscription.unsubscribe();
      gameSubscription.unsubscribe();
    };
  },

  unsubscribeFromGame: () => {
    set({ game: null, moves: [], error: null });
    const chess = new Chess();
    set({ chess });
  }
}));