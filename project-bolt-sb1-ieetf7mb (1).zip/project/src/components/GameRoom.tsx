import React, { useEffect, useState } from 'react';
import { useGameStore } from '../stores/gameStore';
import Chessboard from './Chessboard';
import { Clock, MessageCircle } from 'lucide-react';

interface GameRoomProps {
  gameId: string;
}

interface ChatMessage {
  id: string;
  sender: string;
  message: string;
  timestamp: Date;
}

export default function GameRoom({ gameId }: GameRoomProps) {
  const { game, moves, joinGame, error } = useGameStore();
  const [message, setMessage] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [whiteTime, setWhiteTime] = useState(600); // 10 minutes in seconds
  const [blackTime, setBlackTime] = useState(600);
  const [lastMoveTime, setLastMoveTime] = useState<Date | null>(null);

  useEffect(() => {
    joinGame(gameId);
  }, [gameId]);

  // Timer effect
  useEffect(() => {
    if (!game || game.status !== 'active') return;

    const interval = setInterval(() => {
      if (lastMoveTime) {
        const isWhiteTurn = moves.length % 2 === 0;
        if (isWhiteTurn) {
          setWhiteTime(prev => Math.max(0, prev - 1));
        } else {
          setBlackTime(prev => Math.max(0, prev - 1));
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [game, lastMoveTime, moves.length]);

  // Update last move time when moves change
  useEffect(() => {
    if (moves.length > 0) {
      setLastMoveTime(new Date());
    }
  }, [moves]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleSendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: crypto.randomUUID(),
      sender: 'You', // Replace with actual user name
      message: message.trim(),
      timestamp: new Date(),
    };

    setChatMessages(prev => [...prev, newMessage]);
    setMessage('');
  };

  if (error) {
    return <div className="text-red-500">{error}</div>;
  }

  if (!game) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left sidebar - Black Player info */}
        <div className="space-y-4">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">Black Player</h3>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Player Name</span>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-gray-400 mr-2" />
                <span className="text-gray-300 font-mono">{formatTime(blackTime)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center - Chessboard */}
        <div className="lg:col-span-1">
          <Chessboard />
          <div className="mt-4 flex justify-between items-center">
            <button className="px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400">
              Offer Draw
            </button>
            <button className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-400">
              Resign
            </button>
          </div>
        </div>

        {/* Right sidebar - White Player info, Chat and moves */}
        <div className="space-y-4">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">White Player</h3>
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Player Name</span>
              <div className="flex items-center">
                <Clock className="w-4 h-4 text-gray-400 mr-2" />
                <span className="text-gray-300 font-mono">{formatTime(whiteTime)}</span>
              </div>
            </div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center mb-4">
              <MessageCircle className="w-5 h-5 text-gray-400 mr-2" />
              <h3 className="text-lg font-semibold text-white">Chat</h3>
            </div>
            <div className="h-48 overflow-y-auto mb-4 space-y-2 scrollbar-thin scrollbar-thumb-gray-700">
              {chatMessages.map((msg) => (
                <div key={msg.id} className="bg-gray-700 p-2 rounded">
                  <div className="flex justify-between text-sm">
                    <span className="text-yellow-400">{msg.sender}</span>
                    <span className="text-gray-400">
                      {msg.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-white">{msg.message}</p>
                </div>
              ))}
            </div>
            <div className="flex items-center">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder="Type a message..."
                className="flex-1 bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-500"
              />
              <button
                onClick={handleSendMessage}
                className="ml-2 px-4 py-2 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400"
              >
                Send
              </button>
            </div>
          </div>

          <div className="bg-gray-800 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-white mb-2">Moves</h3>
            <div className="h-48 overflow-y-auto scrollbar-thin scrollbar-thumb-gray-700">
              {moves.map((move, index) => (
                <div key={move.id} className="text-gray-300 py-1 border-b border-gray-700">
                  <span className="text-gray-500">{Math.floor(index / 2) + 1}.</span>{' '}
                  <span className="font-mono">{move.move}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}