import React, { useState } from 'react';
import { useGameStore } from '../stores/gameStore';
import { Copy, Users } from 'lucide-react';

export default function GameLobby() {
  const { createGame, error, loading } = useGameStore();
  const [copied, setCopied] = useState(false);

  const handleCreateGame = async () => {
    await createGame();
  };

  const copyGameLink = () => {
    const gameId = new URLSearchParams(window.location.search).get('gameId');
    if (gameId) {
      navigator.clipboard.writeText(`${window.location.origin}?gameId=${gameId}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-gray-800 rounded-lg shadow-xl">
      <div className="text-center mb-8">
        <Users className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-white mb-2">Game Lobby</h2>
        <p className="text-gray-400">Create a game or join an existing one</p>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-500/10 border border-red-500 rounded text-red-500">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <button
          onClick={handleCreateGame}
          disabled={loading}
          className="w-full px-4 py-3 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Creating...' : 'Create New Game'}
        </button>

        <div className="relative">
          <input
            type="text"
            placeholder="Enter game code"
            className="w-full px-4 py-3 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
          <button
            onClick={copyGameLink}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-400 hover:text-white"
          >
            <Copy className="w-5 h-5" />
          </button>
        </div>

        <button className="w-full px-4 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600">
          Join Game
        </button>
      </div>

      {copied && (
        <div className="mt-4 text-center text-sm text-green-400">
          Game link copied to clipboard!
        </div>
      )}
    </div>
  );
}