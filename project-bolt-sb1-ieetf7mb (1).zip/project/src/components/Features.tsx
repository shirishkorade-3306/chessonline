import React from 'react';
import { Brain, Users, Gamepad2, Trophy, BookOpen, MessageCircle } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Play vs AI',
    description: 'Challenge our advanced AI with adjustable difficulty levels'
  },
  {
    icon: Users,
    title: 'Play with Friends',
    description: 'Create private matches and challenge your friends'
  },
  {
    icon: Gamepad2,
    title: 'Global Matchmaking',
    description: 'Find opponents from around the world instantly'
  },
  {
    icon: Trophy,
    title: 'Tournaments',
    description: 'Compete in daily, weekly, and monthly tournaments'
  },
  {
    icon: BookOpen,
    title: 'Learn & Improve',
    description: 'Access comprehensive tutorials and training resources'
  },
  {
    icon: MessageCircle,
    title: 'Community',
    description: 'Join discussions and connect with other players'
  }
];

export default function Features() {
  return (
    <div className="bg-gray-900 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-white mb-4">
            Everything You Need to Master Chess
          </h2>
          <p className="text-gray-400 text-lg">
            Comprehensive tools and features to enhance your chess journey
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-800 p-6 rounded-xl hover:bg-gray-700 transition-colors">
              <feature.icon className="w-12 h-12 text-yellow-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}