import React from 'react';
import { Sword, Play, BookOpen, Trophy } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-black text-white">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1529699211952-734e80c4d42b?auto=format&fit=crop&q=80")' }}
      />
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <Sword className="h-16 w-16 mx-auto mb-6 text-yellow-400" />
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Play Chess Anytime, Anywhere!
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Join millions of players worldwide in the ultimate chess experience
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button className="flex items-center px-6 py-3 bg-yellow-500 text-black rounded-lg hover:bg-yellow-400 transition-colors">
              <Play className="w-5 h-5 mr-2" />
              Play Now
            </button>
            <button className="flex items-center px-6 py-3 bg-white/10 rounded-lg hover:bg-white/20 transition-colors">
              <BookOpen className="w-5 h-5 mr-2" />
              Learn Chess
            </button>
            <button className="flex items-center px-6 py-3 bg-white/10 rounded-lg hover:bg-white/20 transition-colors">
              <Trophy className="w-5 h-5 mr-2" />
              Tournaments
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}