export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      games: {
        Row: {
          id: string
          white_player: string | null
          black_player: string | null
          current_position: string
          status: 'waiting' | 'active' | 'completed' | 'abandoned'
          winner: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          white_player?: string | null
          black_player?: string | null
          current_position?: string
          status?: 'waiting' | 'active' | 'completed' | 'abandoned'
          winner?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          white_player?: string | null
          black_player?: string | null
          current_position?: string
          status?: 'waiting' | 'active' | 'completed' | 'abandoned'
          winner?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      moves: {
        Row: {
          id: string
          game_id: string
          player_id: string
          move: string
          position: string
          created_at: string
        }
        Insert: {
          id?: string
          game_id: string
          player_id: string
          move: string
          position: string
          created_at?: string
        }
        Update: {
          id?: string
          game_id?: string
          player_id?: string
          move?: string
          position?: string
          created_at?: string
        }
      }
      game_invites: {
        Row: {
          id: string
          game_id: string
          from_user: string
          to_user: string
          status: 'pending' | 'accepted' | 'rejected'
          created_at: string
        }
        Insert: {
          id?: string
          game_id: string
          from_user: string
          to_user: string
          status?: 'pending' | 'accepted' | 'rejected'
          created_at?: string
        }
        Update: {
          id?: string
          game_id?: string
          from_user?: string
          to_user?: string
          status?: 'pending' | 'accepted' | 'rejected'
          created_at?: string
        }
      }
    }
  }
}