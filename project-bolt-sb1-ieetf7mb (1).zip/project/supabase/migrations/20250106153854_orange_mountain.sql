/*
  # Create Game Tables

  1. New Tables
    - `games`
      - `id` (uuid, primary key)
      - `white_player` (uuid, references auth.users)
      - `black_player` (uuid, references auth.users)
      - `current_position` (text, FEN notation)
      - `status` (game_status)
      - `winner` (uuid, references auth.users)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `moves`
      - `id` (uuid, primary key)
      - `game_id` (uuid, references games)
      - `player_id` (uuid, references auth.users)
      - `move` (text, algebraic notation)
      - `position` (text, FEN notation)
      - `created_at` (timestamp)
    - `game_invites`
      - `id` (uuid, primary key)
      - `game_id` (uuid, references games)
      - `from_user` (uuid, references auth.users)
      - `to_user` (uuid, references auth.users)
      - `status` (invite_status)
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for game access and moves
*/

-- Create custom types
CREATE TYPE game_status AS ENUM ('waiting', 'active', 'completed', 'abandoned');
CREATE TYPE invite_status AS ENUM ('pending', 'accepted', 'rejected');

-- Create games table
CREATE TABLE IF NOT EXISTS games (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  white_player uuid REFERENCES auth.users,
  black_player uuid REFERENCES auth.users,
  current_position text NOT NULL DEFAULT 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1',
  status game_status NOT NULL DEFAULT 'waiting',
  winner uuid REFERENCES auth.users,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create moves table
CREATE TABLE IF NOT EXISTS moves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES games ON DELETE CASCADE NOT NULL,
  player_id uuid REFERENCES auth.users NOT NULL,
  move text NOT NULL,
  position text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Create game invites table
CREATE TABLE IF NOT EXISTS game_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game_id uuid REFERENCES games ON DELETE CASCADE NOT NULL,
  from_user uuid REFERENCES auth.users NOT NULL,
  to_user uuid REFERENCES auth.users NOT NULL,
  status invite_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE moves ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_invites ENABLE ROW LEVEL SECURITY;

-- Games policies
CREATE POLICY "Users can view their own games"
  ON games
  FOR SELECT
  USING (
    auth.uid() = white_player OR 
    auth.uid() = black_player
  );

CREATE POLICY "Users can create games"
  ON games
  FOR INSERT
  WITH CHECK (auth.uid() = white_player OR auth.uid() = black_player);

CREATE POLICY "Players can update their games"
  ON games
  FOR UPDATE
  USING (
    auth.uid() = white_player OR 
    auth.uid() = black_player
  );

-- Moves policies
CREATE POLICY "Users can view moves for their games"
  ON moves
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM games
      WHERE games.id = moves.game_id
      AND (games.white_player = auth.uid() OR games.black_player = auth.uid())
    )
  );

CREATE POLICY "Players can create moves for their games"
  ON moves
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM games
      WHERE games.id = moves.game_id
      AND (games.white_player = auth.uid() OR games.black_player = auth.uid())
      AND games.status = 'active'
    )
  );

-- Game invites policies
CREATE POLICY "Users can view their invites"
  ON game_invites
  FOR SELECT
  USING (
    auth.uid() = from_user OR 
    auth.uid() = to_user
  );

CREATE POLICY "Users can create invites"
  ON game_invites
  FOR INSERT
  WITH CHECK (auth.uid() = from_user);

CREATE POLICY "Users can update their received invites"
  ON game_invites
  FOR UPDATE
  USING (auth.uid() = to_user);